﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Build.Evaluation;

namespace CoreMVCCategoryProduct.Models
{
    [ModelMetadataType(typeof(ProductMetadata))]
    public partial class Product
    {
    }

}
