﻿How to create Master Detail entry form in asp.net MVC4
http://www.dotnetawesome.com/2015/09/how-to-create-master-detail-entry-form-in-aspnet-mvc4.html