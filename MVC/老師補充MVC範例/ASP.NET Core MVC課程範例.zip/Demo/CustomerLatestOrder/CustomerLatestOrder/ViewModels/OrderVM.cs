﻿namespace CustomerLastOrder.ViewModels
{
    public class OrderVM
    {
        public int OrderId { get; set; }
        public DateTime? OrderDate { get; set; }

    }
}
