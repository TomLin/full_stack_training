﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class FuenController1 : Controller
    {
        public IActionResult Index()
        {
            return View();        //Imdex.cshtml
        }
    }
}
