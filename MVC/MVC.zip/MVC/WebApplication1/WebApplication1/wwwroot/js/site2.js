﻿function test2() {
    alert("test2");
}