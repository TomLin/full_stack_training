function test1() {
    alert("test1");
}
function test2() {
    alert("test2");
}