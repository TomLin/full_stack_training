﻿function test1() {
    alert("test1");
}